package com.example.shopping.controller;

import com.example.shopping.entity.Item;
import com.example.shopping.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/items") 
public class ItemController {

    @Autowired
    private ItemService itemService;

   
    @PostMapping("/addItem")
    public Item addItem(@RequestBody Item item) {
        return itemService.addItem(item);
    }


    @GetMapping("/getItemByCode/{code}")
    public Item getItem(@PathVariable String code) {
        return itemService.getItemByCode(code);
    }

 
    @PutMapping("/updatePrice/{code}")
    public Item updatePrice(@PathVariable String code, @RequestParam BigDecimal price) {
        return itemService.updateItemPrice(code, price);
    }
}
