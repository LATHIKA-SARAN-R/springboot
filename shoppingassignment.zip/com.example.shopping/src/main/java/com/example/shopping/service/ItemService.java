package com.example.shopping.service;

import com.example.shopping.entity.Item;
import com.example.shopping.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

   
    public Item addItem(Item item) {
        return itemRepository.save(item);
    }

   
    public Item getItemByCode(String code) {
        Item item = itemRepository.findById(code).orElse(null);
        return item;
    }

  
    public Item updateItemPrice(String code, BigDecimal newPrice) {
        Item item = getItemByCode(code);
        if (item != null) {
            item.setPrice(newPrice);
            itemRepository.save(item);
        }
        return item;
    }
}
