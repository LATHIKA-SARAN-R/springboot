package com.example.demo.Service;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.demo.Entity.Customer;
import com.example.demo.JpaRespo.CustomerRepo;
import java.util.Optional;

 
@Service
public class CustomerService {
	
	@Autowired
	CustomerRepo Respo;
	public  Customer dsaveD(Customer c )
	 {
	    Customer  c1=	Respo.save(c);
	    return c1;
		
	 }
	
	public Customer getSearch(int ac)
	{
		 return Respo.findById(ac).orElse(null);
		
	}
	
	  public List<Customer> getAllCustomers() {
	        return Respo.findAll();
	    }

	  
	    public boolean deleteCustomer(int ac) {
	        if (Respo.existsById(ac)) {
	            Respo.deleteById(ac);
	            return true;
	        }
	        return false;
	    }
	    
	    public boolean depositToAccount(int accno, double amt) {
	        Optional<Customer> optionalCustomer = Respo.findById(accno);

	        if (optionalCustomer.isPresent()) {
	            Customer customer = optionalCustomer.get();
	            double updatedBalance = customer.getBalance() + amt;
	            customer.setBalance(updatedBalance);
	            Respo.save(customer);  
	            return true;
	        }

	        return false;  
	    }

 
}
