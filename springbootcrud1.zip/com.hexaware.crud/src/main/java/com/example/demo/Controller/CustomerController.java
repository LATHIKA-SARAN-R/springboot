package com.example.demo.Controller;
 
import org.springframework.web.bind.annotation.RestController;
 
import com.example.demo.Entity.Customer;
import com.example.demo.Service.CustomerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

 
 
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService  service;
	
	@PostMapping("/saveData")
	public Customer saveData1( @RequestBody Customer c)
	{
		
		Customer c1= service.dsaveD(c);
		return c1;
		
	}
	
	// search by accno
	@GetMapping("/getdataAc/{ac}")
	 
	 
    public  Customer getByAct(@PathVariable int  ac)
    {
		   
		  return  service.getSearch(ac);  
		   
    }
	
	 @GetMapping("/getAllData")
	    public List<Customer> getAllData() {
	        return service.getAllCustomers();
	    }

	   
	    @DeleteMapping("/deleteData/{ac}")
	    public String deleteCustomer(@PathVariable int ac) {
	        boolean deleted = service.deleteCustomer(ac);
	        if (deleted) {
	            return "Customer with account number " + ac + " deleted successfully.";
	        } else {
	            return "Customer with account number " + ac + " not found.";
	        }
	    }
	    @PutMapping("/deposit/{accno}/{amt}")
	    public String depositAmount(@PathVariable int accno, @PathVariable double amt) {
	        boolean result = service.depositToAccount(accno, amt);
	        if (result) {
	            return "Amount " + amt + " deposited successfully to account " + accno;
	        } else {
	            return "Account number " + accno + " not found!";
	        }
	    }
	
	
	
	
	
 
}