package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Customer;
import com.example.demo.Service.CustomerService;

@RestController
public class CustomerController {

    @Autowired
    CustomerService service;

    @PostMapping("/save")
    public Customer saveCustomer(@RequestBody Customer c) {
        return service.saveCustomer(c);
    }

    @GetMapping("/get/{actno}")
    public Customer getCustomer(@PathVariable int actno) {
        return service.getCustomer(actno);
    }

    @GetMapping("/getAll")
    public List<Customer> getAllCustomers() {
        return service.getAll();
    }

    @DeleteMapping("/delete/{actno}")
    public String deleteCustomer(@PathVariable int actno) {
        return service.deleteCustomer(actno);
    }

    @PutMapping("/deposit/{actno}/{amt}")
    public String deposit(@PathVariable int actno, @PathVariable double amt) {
        return service.deposit(actno, amt);
    }

    @PutMapping("/withdraw/{actno}/{amt}")
    public String withdraw(@PathVariable int actno, @PathVariable double amt) {
        return service.withdraw(actno, amt);
    }
}

	
	
 
