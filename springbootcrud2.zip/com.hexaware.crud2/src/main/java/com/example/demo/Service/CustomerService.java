package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Customer;
import com.example.demo.JpaRespo.CustomerRepo;

@Service
public class CustomerService {

    @Autowired
    CustomerRepo repo;

    public Customer saveCustomer(Customer c) {
        return repo.save(c);
    }

    public Customer getCustomer(int actno) {
        return repo.getCustomerByActno(actno);
    }

    public List<Customer> getAll() {
        return repo.getAllCustomers();
    }

    public String deleteCustomer(int actno) {
        Customer c = repo.getCustomerByActno(actno);
        if (c != null) {
            repo.deleteByActno(actno);
            return "Customer deleted";
        } else {
            return "Customer not found";
        }
    }

    public String deposit(int actno, double amt) {
        int updated = repo.depositAmount(actno, amt);
        if (updated > 0) {
            return "Amount deposited";
        } else {
            return "Deposit failed";
        }
    }

    public String withdraw(int actno, double amt) {
        int updated = repo.withdrawAmount(actno, amt);
        if (updated > 0) {
            return "Amount withdrawn";
        } else {
            return "Withdraw failed (Min Balance ₹1000 required)";
        }
    }
}

