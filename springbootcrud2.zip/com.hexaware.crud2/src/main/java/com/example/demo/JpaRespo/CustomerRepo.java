package com.example.demo.JpaRespo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entity.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Integer> {

    //@Query("SELECT c FROM Customer c")
	@Query(value="select * from customer",nativeQuery = true)
    public List<Customer> getAllCustomers();

    //@Query("SELECT c FROM Customer c WHERE c.actno = :actno")
	@Query(value="select * from Cutomer where actno=:actno",nativeQuery =true)
    public Customer getCustomerByActno(@Param("actno") int actno);

    @Transactional
    @Modifying
    //@Query("DELETE FROM Customer c WHERE c.actno = :actno")
    @Query(value = "DELETE FROM Customer WHERE actno = :actno", nativeQuery = true)
    public void deleteByActno(@Param("actno") int actno);

    @Transactional
    @Modifying
    //@Query("UPDATE Customer c SET c.balance = c.balance + :amt WHERE c.actno = :actno")
    @Query(value = "UPDATE Customer SET balance = balance + :amt WHERE actno = :actno", nativeQuery = true)
    public int depositAmount(@Param("actno") int actno, @Param("amt") double amt);

    @Transactional
    @Modifying
    //@Query("UPDATE Customer c SET c.balance = c.balance - :amt WHERE c.actno = :actno AND c.balance - :amt >= 1000")
    @Query(value = "UPDATE Customer SET balance = balance - :amt WHERE actno = :actno AND balance - :amt >= 1000", nativeQuery = true)
    public int withdrawAmount(@Param("actno") int actno, @Param("amt") double amt);
}
