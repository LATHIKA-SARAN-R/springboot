package com.example.bookapi.controller;

import com.example.bookapi.entity.User;
import com.example.bookapi.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        if ("user".equals(user.getUsername()) && "pass".equals(user.getPassword())) {
            return jwtUtil.generateToken(user.getUsername());
        } else {
            return "Invalid credentials";
        }
    }
}
