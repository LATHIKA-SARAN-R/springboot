package com.example.bookapi.controller;

import com.example.bookapi.dto.BookDTO;
import com.example.bookapi.service.BookService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;




@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService service;

    @GetMapping
    public List<BookDTO> getAllBooks() {
        return service.getAllBooks();
    }

    @GetMapping("/{isbn}")
    public BookDTO getBookByIsbn(@PathVariable String isbn) {
        return service.getBookByIsbn(isbn);
    }

    @PostMapping("/books")
    public ResponseEntity<BookDTO> addBook(@Valid @RequestBody BookDTO bookDto) {
        BookDTO saved = service.addBook(bookDto);  
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }


    @PutMapping("/{isbn}")
    public BookDTO updateBook(@PathVariable String isbn, @RequestBody BookDTO dto) {
        return service.updateBook(isbn, dto);
    }

    @DeleteMapping("/{isbn}")
    public String deleteBook(@PathVariable String isbn) {
        service.deleteBook(isbn);
        return "Book deleted successfully.";
    }
}
