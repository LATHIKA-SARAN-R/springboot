package com.example.bookapi.service;

import com.example.bookapi.dto.BookDTO;
import com.example.bookapi.entity.Book;
import com.example.bookapi.exception.BookNotFoundException;
import com.example.bookapi.mapper.BookMapper;
import com.example.bookapi.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BookService {

    @Autowired
    private BookRepository repository;

    public List<BookDTO> getAllBooks() {
        List<Book> books = repository.findAll();
        List<BookDTO> dtos = new ArrayList<>();
        for (Book book : books) {
            dtos.add(BookMapper.toDTO(book));
        }
        return dtos;
    }

    public BookDTO getBookByIsbn(String isbn) {
        Book book = repository.findById(isbn)
            .orElseThrow(() -> new BookNotFoundException("Book not found with ISBN: " + isbn));
        return BookMapper.toDTO(book);
    }

    public BookDTO addBook(BookDTO dto) {
        Book book = BookMapper.toEntity(dto);
        Book saved = repository.save(book);
        return BookMapper.toDTO(saved);
    }

    public BookDTO updateBook(String isbn, BookDTO dto) {
        Book book = repository.findById(isbn)
            .orElseThrow(() -> new BookNotFoundException("Book not found with ISBN: " + isbn));
        
        book.setTitle(dto.getTitle());
        book.setAuthor(dto.getAuthor());
        book.setPublicationYear(dto.getPublicationYear());

        return BookMapper.toDTO(repository.save(book));
    }

    public void deleteBook(String isbn) {
        if (!repository.existsById(isbn)) {
            throw new BookNotFoundException("Book not found with ISBN: " + isbn);
        }
        repository.deleteById(isbn);
    }
}
